Exact executed shared-model notebooks before restoring the complete evidence-to-anatomy workflow. Extract into the repository root to run. No model or result files were changed.
