"""Reusable public entry point for Trial1, Trial2, Trial3 and trial configs.

    model = BodyModel(height_cm=180)
    result = model.fit('trial2', project=Path.cwd(), frames='verification')

The complete specification is always reported. Missing physiological models or
parameters remain unknown; selecting a profile cannot manufacture a pass.
"""
from dataclasses import dataclass
from pathlib import Path
from .body_constraints import coverage_table
from .inverse_kinematics import make_body


@dataclass(frozen=True)
class BodyModel:
    height_cm: float = 180.
    ratios: dict | None = None

    def __post_init__(self):make_body(self.height_cm,self.ratios)

    @property
    def constraints(self):return coverage_table()

    def fit(self, trial, project=None, frames='verification', iterations=150,
            candidates=('legacy_control','balanced','steady'), output_root=None, render=True, progress=print):
        """Fit one continuous interval; pass frames='all' for the full sequence."""
        from .body_pipeline import run
        return run(self,Path.cwd() if project is None else project,trial,frames,
                   iterations,candidates,output_root,render,progress)
