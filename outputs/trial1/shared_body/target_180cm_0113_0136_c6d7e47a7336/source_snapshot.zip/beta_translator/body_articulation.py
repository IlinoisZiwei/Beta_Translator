"""One source-checked body/contact model for every trial."""
import numpy as np
from .body_optimizer import AnatomicalProblem, audit as old_audit
from .body_reference import stage1_kinematics
from .body_contacts import foot_frames
from .body_constraints import DEFAULT_LIMITS

class BodyProblem(AnatomicalProblem):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.foot_frames, self.foot_offset, self.foot_modes, self.foot_evidence = foot_frames(
            self.data, self.scene, self.regions, self.height)

    def body_kinematics(self, q):
        return stage1_kinematics(q, self.lengths, self.height)

    def geometry(self, y):
        g = super().geometry(y)
        foot = g['joints'][:, 2:, 2]+self.foot_offset
        points = np.concatenate([g['palm_contacts'], foot], axis=1)
        # One residual: p_joint + R_segment*r_patch - c_surface.
        # targets are the EXACT equivalent wrist/ankle locations, not a second
        # fixed-offset objective. Fit, audit, forces and renderer share points.
        g.update(contact_points=points, contact_targets=g['contacts'],
                 targets=g['contacts']-(points-g['joints'][:, :, 2]),
                 foot_contacts=foot, foot_frames=self.foot_frames,
                 foot_heel=foot-.07*self.height*self.foot_frames[:, :, :, 0])
        return g


def audit_body(fit, data, scene, regions, height=180., ratios=None):
    m, gaps, forces = old_audit(fit, data, scene, regions, height, ratios)
    m['hand_patch_gap_cm'] = np.max(np.where(data['known'][:, :2], gaps[:, :2], 0), axis=1)
    m['foot_patch_gap_cm'] = np.max(np.where(data['known'][:, 2:], gaps[:, 2:], 0), axis=1)
    m['grip_proxy_gap_cm'] = m.hand_patch_gap_cm
    m['grip_proxy_failed'] = m.hand_patch_gap_cm > DEFAULT_LIMITS.contact_cm
    # A separate diagnostic retains the old target mismatch, never optimizes it.
    from .body_contacts import contact_geometry
    _, offsets, _, _ = contact_geometry(scene, regions, fit['episode_uv'], 'region_offset')
    old_gap = np.linalg.norm(fit['joints'][:, :, 2]-(fit['contacts']+offsets), axis=-1)
    m['legacy_joint_target_gap_cm'] = np.max(np.where(data['known'], old_gap, 0), axis=1)
    agreement = np.linalg.norm((fit['joints'][:, :, 2]-fit['targets'])-(fit['contact_points']-fit['contacts']), axis=-1)
    m['contact_definition_disagreement_cm'] = agreement.max(axis=1)
    m['foot_orientation_uncertain'] = True
    m['ankle_rom_checked'] = False
    switches = np.zeros(len(m), bool)
    switches[1:] = np.any(data['known'][1:] & data['known'][:-1] & (data['labels'][1:] != data['labels'][:-1]), axis=1)
    m['direct_contact_switch_uncertain'] = switches
    m['issues'] = m.issues.astype(str)+';foot_frame_inferred;ankle_rom_unchecked'
    m.loc[switches, 'issues'] += ';contact_switch_without_free_frame'
    return m, gaps, forces


