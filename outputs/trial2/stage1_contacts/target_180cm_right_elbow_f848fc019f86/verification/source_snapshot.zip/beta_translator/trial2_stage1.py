"""Stage 1: source-checked arm rotations and one hand/foot contact geometry.

This is still a reduced fixed-length model. Foot frames are conditional surface
and image hypotheses, NOT a new anatomical ankle or a measured shoe orientation.
Historical anatomical and spatial experiments retain their original defaults.
"""
from functools import lru_cache
from pathlib import Path
import json
import numpy as np
from scipy.spatial.transform import Rotation
from . import anatomical_arms as arms
from .trial2_anatomy_optimizer import AnatomicalProblem, audit as old_audit


@lru_cache(maxsize=1)
def source_reference():
    return json.loads((Path(__file__).resolve().parents[1]/'data/trial2_stage1_chain_reference.json').read_text())


def source_curve(x, knots, values):
    """Two/three-knot SimmSpline special case, with endpoint tangent extrapolation.

    OpenSim 4.5's two-point curve is linear; its three-point end conditions
    give a quadratic. No general SimmSpline implementation is claimed here.
    Real-valued branch selection preserves complex-step derivatives.
    """
    knots, values = np.asarray(knots), np.asarray(values)
    if len(knots) not in (2, 3):
        raise ValueError('Only the verified two/three-knot source curves are supported')
    coef = np.polyfit(knots, values, len(knots)-1)
    y = np.polyval(coef, x)
    derivative = np.polyder(coef)
    for end, mask in [(0, np.real(x)<knots[0]), (-1, np.real(x)>knots[-1])]:
        y = np.where(mask, values[end]+(x-knots[end])*np.polyval(derivative, knots[end]), y)
    return y


def coupled_arm_frames(q):
    """Source rotational chain from scapphant to hand; project lengths retained."""
    A, F, _ = arms.arm_frames(q)
    _, _, _, _, s, d, f = np.moveaxis(q, -1, 0)
    ref = source_reference()
    joints = {j['name']:j for j in ref['joints']}
    couplers = {j['coordinate']:j for j in ref['couplers']}
    def rot(angle, axis):
        a = np.asarray(axis); a = a/np.linalg.norm(a)
        R = arms.axis_rotation(angle, a)
        return arms.OSIM_TO_BODY@R@arms.OSIM_TO_BODY.T
    carpal = joints['radiocarpal']['rotations']
    distal = joints['wrist_hand']['rotations']
    rc = rot(d, carpal[0]['axis'])@rot(source_curve(f, carpal[1]['x'], carpal[1]['y']), carpal[1]['axis'])
    dc = couplers['wrist_hand_r1']; fc = couplers['wrist_hand_r3']
    hand = rot(source_curve(d, dc['x'], dc['y']), distal[0]['axis'])@rot(source_curve(f, fc['x'], fc['y']), distal[1]['axis'])
    H = F@rot(s, joints['radioulnar']['rotations'][0]['axis'])@rc@hand
    return A, F, H


def stage1_kinematics(q, lengths, height):
    """Correct distal hand frames without stretching or repositioning arm bones."""
    g = arms.kinematics(q, lengths, height)
    q = np.atleast_2d(q); torso = g['orientations'][:, 0]
    for side in range(2):
        _, _, H = coupled_arm_frames(q[:, 6+7*side:13+7*side])
        if side == 0:
            H = arms.MIRROR@H@arms.MIRROR
        H = torso@H
        g['orientations'][:, 3+3*side] = H
        g['hand_tips'][:, side] = g['joints'][:, side, 2]-.035*height*H[:, :, 1]
        g['palm_contacts'][:, side] = g['hand_tips'][:, side]-.012*height*H[:, :, 2]
    return g


def foot_frames(data, scene, regions, height):
    """One explicit shoe frame per stance episode, no independently fitted offset.

    Columns are toe direction, transverse direction, outward surface normal.
    Surface-aligned sole is a declared hypothesis; toe direction is estimated
    from ankle/contact evidence or heel/toe image evidence on the floor.
    """
    n = len(data['frames']); mapping = regions['mapping']
    frames = np.broadcast_to(np.eye(3), (n, 2, 3, 3)).copy()
    offsets = np.zeros((n, 2, 3)); modes = np.full((n, 2), 'unobserved', dtype='U32')
    evidence = []
    for e in regions['episodes']:
        limb = e['limb_index']
        if limb < 2:
            continue
        active = mapping[:, limb] == e['episode']
        if not active.any():
            continue
        normal = scene.normals[e['panel']].copy()
        toe = -np.asarray(e['offset_cm']); toe -= toe@normal*normal
        source = 'episode ankle-to-contact image direction'
        if e['ground_proposal']:
            heel = 19 if limb == 2 else 22
            toes = [17, 18] if limb == 2 else [20, 21]
            samples = []
            for t in np.flatnonzero(active):
                ids = [heel, *toes]
                if np.min(data['scores'][t, ids]) <= .5:
                    continue
                pts = scene.intersect(data['points'][t, ids], 3)
                v = pts[1:].mean(0)-pts[0]; v -= v@normal*normal
                if np.linalg.norm(v) > 1e-6:
                    samples.append(v/np.linalg.norm(v))
            toe = np.median(samples, axis=0) if samples else np.array([0., 0., -1.])
            source = 'floor heel/toe image hypothesis' if samples else 'floor forward-direction fallback'
        if np.linalg.norm(toe) < 1e-6:
            toe = np.array([0., 1., 0.]); toe -= toe@normal*normal
            if np.linalg.norm(toe) < 1e-6:
                toe = np.array([0., 0., -1.]); toe -= toe@normal*normal
            source = 'surface tangent fallback: sparse evidence'
        toe /= np.linalg.norm(toe)
        frame = np.stack([toe, np.cross(normal, toe), normal], axis=1)
        # Local ankle-to-patch vector. Ground uses the sole under the ankle;
        # wall holds use a forefoot proxy. The constants remain assumptions.
        local = height*np.array([0., 0., -.035] if e['ground_proposal'] else [.045, 0., -.025])
        frames[active, limb-2] = frame
        offsets[active, limb-2] = frame@local
        modes[active, limb-2] = 'ground_sole' if e['ground_proposal'] else 'wall_forefoot'
        evidence.append(dict(episode=e['episode'], limb=e['limb'], frame_world=frame.tolist(),
            ankle_to_patch_local_cm=local.tolist(), direction_source=source,
            sole_normal_status='assumed_from_scene_surface', ankle_rom_status='not_checked',
            measured=False, evidence_frames=e['evidence_frames']))
    return frames, offsets, modes, evidence


class Stage1Problem(AnatomicalProblem):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.foot_frames, self.foot_offset, self.foot_modes, self.foot_evidence = foot_frames(
            self.data, self.scene, self.regions, self.height)

    def body_kinematics(self, q):
        return stage1_kinematics(q, self.lengths, self.height)

    def geometry(self, y):
        g = super().geometry(y)
        foot = g['joints'][:, 2:, 2]+self.foot_offset
        points = np.concatenate([g['palm_contacts'], foot], axis=1)
        # One residual: p_joint + R_segment*r_patch - c_surface.
        # targets are the EXACT equivalent wrist/ankle locations, not a second
        # fixed-offset objective. Fit, audit, forces and renderer share points.
        g.update(contact_points=points, contact_targets=g['contacts'],
                 targets=g['contacts']-(points-g['joints'][:, :, 2]),
                 foot_contacts=foot, foot_frames=self.foot_frames,
                 foot_heel=foot-.07*self.height*self.foot_frames[:, :, :, 0])
        return g


def audit_stage1(fit, data, scene, regions, height=180.):
    m, gaps, forces = old_audit(fit, data, scene, regions, height)
    m['hand_patch_gap_cm'] = np.max(np.where(data['known'][:, :2], gaps[:, :2], 0), axis=1)
    m['foot_patch_gap_cm'] = np.max(np.where(data['known'][:, 2:], gaps[:, 2:], 0), axis=1)
    m['grip_proxy_gap_cm'] = m.hand_patch_gap_cm
    m['grip_proxy_failed'] = m.hand_patch_gap_cm > .1
    # A separate diagnostic retains the old target mismatch, never optimizes it.
    from .trial2_spatial_optimizer import contact_geometry
    _, offsets, _, _ = contact_geometry(scene, regions, fit['episode_uv'], 'region_offset')
    old_gap = np.linalg.norm(fit['joints'][:, :, 2]-(fit['contacts']+offsets), axis=-1)
    m['legacy_joint_target_gap_cm'] = np.max(np.where(data['known'], old_gap, 0), axis=1)
    agreement = np.linalg.norm((fit['joints'][:, :, 2]-fit['targets'])-(fit['contact_points']-fit['contacts']), axis=-1)
    m['contact_definition_disagreement_cm'] = agreement.max(axis=1)
    m['foot_orientation_uncertain'] = True
    m['ankle_rom_checked'] = False
    switches = np.zeros(len(m), bool)
    switches[1:] = np.any(data['known'][1:] & data['known'][:-1] & (data['labels'][1:] != data['labels'][:-1]), axis=1)
    m['direct_contact_switch_uncertain'] = switches
    m['issues'] = m.issues.astype(str)+';foot_frame_inferred;ankle_rom_unchecked'
    m.loc[switches, 'issues'] += ';contact_switch_without_free_frame'
    return m, gaps, forces


def verify_chain(samples=128):
    """Independent source-parameter matrix composition (SciPy rotation oracle).

    Verifies the ROTATIONAL subchain; translational source offsets are explicitly
    excluded. Does not substitute for an OpenSim simulation or human validation.
    """
    ref = source_reference(); rng = np.random.default_rng(5810)
    bounds = np.deg2rad(arms.ARM_LIMITS_DEG)
    qs = rng.uniform(bounds[:, 0], bounds[:, 1], (samples, 7))
    # Independent three-point polynomial interpolation using a Vandermonde solve.
    def curve(x, spec):
        if spec['function'] == 'LinearFunction':
            return spec['coefficients'][0]*x+spec['coefficients'][1]
        xx, yy = np.array(spec['x']), np.array(spec['y'])
        coef = np.linalg.solve(np.vander(xx), yy)
        y = np.polyval(coef, x)
        for k in (0, -1):
            if (k == 0 and x < xx[k]) or (k == -1 and x > xx[k]):
                y = yy[k]+(x-xx[k])*np.polyval(np.polyder(coef), xx[k])
        return y
    expected = []
    for q in qs:
        coords = dict(zip(arms.ARM_NAMES, q))
        for c in ref['couplers']:
            coords[c['coordinate']] = curve(coords[c['independent']], c)
        R = np.eye(3); frames = {}
        for j in ref['joints']:
            assert not np.any(j['orientation_in_parent']) and not np.any(j['orientation'])
            for a in j['rotations']:
                axis = np.asarray(a['axis']); axis /= np.linalg.norm(axis)
                R = R@Rotation.from_rotvec(axis*curve(coords[a['coordinate']], a)).as_matrix()
            frames[j['child']] = arms.OSIM_TO_BODY@R@arms.OSIM_TO_BODY.T
        expected.append([frames[n] for n in ['humerus', 'ulna', 'hand']])
    expected = np.asarray(expected)
    actual = np.stack(coupled_arm_frames(qs), axis=1)
    old = np.stack(arms.arm_frames(qs), axis=1)
    error = np.max(abs(actual-expected))
    old_angles = arms.rotation_steps_deg(np.stack([old[:, 2], expected[:, 2]], axis=0), 1)
    return dict(source_sha256=ref['source_sha256'], random_poses=samples,
        rotation_matrix_max_absolute_error=float(error), rotational_chain_pass=bool(error<1e-10),
        previous_hand_orientation_max_difference_deg=float(np.max(old_angles)),
        fixed_length_reduction=True, source_translation_offsets_imported=False,
        source_rest_offsets_m={j['name']:j['location_in_parent'] for j in ref['joints']},
        source_girdle_imported=False, opensim_engine_crosscheck=False,
        conclusion='Source rotational subchain checked independently; omitted translations and girdle motion remain a declared reduction.')
